# ELFIS Tag Toggle Toolbar for SketchUp
# Save this file as: elfis_tag_toolbar.rb
#
# Each button toggles one or more SketchUp tags.

module ELFIS_TagToolbar

  BUTTONS = [
    { id: :room, label: "Room", tags: ["Walls", "Ceiling", "Floor"] },
    { id: :facade, label: "Facade", tags: ["Facade"] },
    { id: :body, label: "Body", tags: ["Body"] },
    { id: :back_wall, label: "Back Wall", tags: ["Back Wall"] },
    { id: :worktops, label: "Worktops", tags: ["Worktops"] },
    { id: :handles, label: "Handles", tags: ["Handles"] },
    {
      id: :hardware,
      label: "Hardware",
      tags: ["Hardware", "Blum Hardware", "Extra Blum Hardware"]
    },
    { id: :appliances, label: "Appliances", tags: ["Appliances"] },
    {
      id: :operations,
      label: "Blum Operations",
      tags: ["Blum Operations", "Blum Operations (unbound)"]
    },
    { id: :dimensions, label: "Dimensions", tags: ["Dimensions"] }
  ]

  TAG_FOLDERS = {
    "00 Room" => ["Walls", "Ceiling", "Floor"],
    "01 Cabinet Parts" => ["Facade", "Body", "Back Wall", "Worktops"],
    "02 Hardware" => ["Handles", "Hardware", "Blum Hardware", "Extra Blum Hardware"],
    "03 Appliances" => ["Appliances"],
    "04 Machining" => ["Blum Operations", "Blum Operations (unbound)"],
    "05 Documentation" => ["Dimensions"]
  }

  @toolbar = nil
  @commands = {}
  @app_observer = nil

  def self.ensure_tags(model = Sketchup.active_model)
    return unless model

    layers = model.layers

    TAG_FOLDERS.each do |folder_name, tag_names|
      folder = layers.folders.find { |item| item.name == folder_name }
      folder ||= layers.add_folder(folder_name)

      tag_names.each do |tag_name|
        tag = layers[tag_name] || layers.add(tag_name)
        folder.add_layer(tag) unless tag.folder == folder
      end
    end

    machining_folder = layers.folders.find { |item| item.name == "04 Machining" }
    layers.each do |tag|
      next unless tag.name.match?(/\AD\d+(?:[._]\d+)?_DEPTH\d+(?:[._]\d+)?\z/i)

      machining_folder.add_layer(tag) unless tag.folder == machining_folder
    end
  end

  class AppObserver < Sketchup::AppObserver
    def onNewModel(model)
      ELFIS_TagToolbar.ensure_tags(model)
      ELFIS_TagToolbar.refresh
    end

    def onOpenModel(model)
      ELFIS_TagToolbar.ensure_tags(model)
      ELFIS_TagToolbar.refresh
    end
  end

  def self.icon_folder
    folder = File.join(Sketchup.temp_dir, "ELFIS_TagToolbar")
    Dir.mkdir(folder) unless Dir.exist?(folder)
    folder
  end

  def self.icon_markup(icon_id)
    blue = "#075d99"
    red = "#43bde3"
    grey = "#174562"

    case icon_id
    when :room
      <<~SVG
        <path d="M10 17 L32 8 L54 17 V50 H10 Z" fill="none" stroke="#{blue}" stroke-width="3" stroke-linejoin="round"/>
        <path d="M17 23 H47 V48 H17 Z" fill="none" stroke="#{red}" stroke-width="2.5"/>
        <path d="M27 48 V32 H38 V48" fill="none" stroke="#{grey}" stroke-width="3" stroke-linejoin="round"/>
        <circle cx="35" cy="40" r="1.8" fill="#{red}"/>
      SVG
    when :facade
      <<~SVG
        <rect x="16" y="8" width="32" height="48" rx="2" fill="none" stroke="#{blue}" stroke-width="3"/>
        <rect x="21" y="13" width="22" height="38" rx="1" fill="none" stroke="#{red}" stroke-width="2"/>
        <rect x="38" y="26" width="3.5" height="13" rx="1.75" fill="#{grey}"/>
        <circle cx="39.75" cy="25" r="1.5" fill="#{blue}"/>
        <circle cx="39.75" cy="40" r="1.5" fill="#{blue}"/>
      SVG
    when :body
      <<~SVG
        <path d="M14 20 L31 11 L50 19 L50 45 L31 54 L14 45 Z" fill="none" stroke="#{blue}" stroke-width="3"/>
        <path d="M31 11 V38 M14 20 L31 28 L50 19 M31 38 L50 45" fill="none" stroke="#{blue}" stroke-width="2"/>
        <line x1="18" y1="23" x2="18" y2="42" stroke="#{red}" stroke-width="4" stroke-linecap="round"/>
        <circle cx="31" cy="38" r="2.5" fill="#{grey}"/>
      SVG
    when :back_wall
      <<~SVG
        <rect x="15" y="10" width="34" height="44" rx="2" fill="none" stroke="#{blue}" stroke-width="3"/>
        <path d="M19 49 L45 15 M19 15 L45 49" fill="none" stroke="#{blue}" stroke-width="2"/>
        <line x1="17" y1="12" x2="47" y2="12" stroke="#{red}" stroke-width="4" stroke-linecap="round"/>
        <circle cx="32" cy="32" r="2.5" fill="#{grey}"/>
      SVG
    when :worktops
      <<~SVG
        <path d="M9 23 L50 17 L56 24 L15 31 Z" fill="none" stroke="#{blue}" stroke-width="3" stroke-linejoin="round"/>
        <path d="M15 31 V39 M50 26 V34" fill="none" stroke="#{blue}" stroke-width="3"/>
        <line x1="10" y1="23" x2="15" y2="31" stroke="#{red}" stroke-width="4" stroke-linecap="round"/>
        <circle cx="50" cy="17" r="2.5" fill="#{grey}"/>
      SVG
    when :handles
      <<~SVG
        <circle cx="17" cy="39" r="4" fill="none" stroke="#{grey}" stroke-width="3"/>
        <circle cx="47" cy="39" r="4" fill="none" stroke="#{grey}" stroke-width="3"/>
        <path d="M17 39 C18 18 46 18 47 39" fill="none" stroke="#{blue}" stroke-width="5" stroke-linecap="round"/>
        <path d="M21 35 C24 24 40 24 43 35" fill="none" stroke="#{red}" stroke-width="2.5" stroke-linecap="round"/>
      SVG
    when :hardware
      <<~SVG
        <rect x="7" y="17" width="19" height="30" rx="3" fill="none" stroke="#{grey}" stroke-width="4"/>
        <circle cx="16.5" cy="32" r="5" fill="none" stroke="#{red}" stroke-width="3"/>
        <path d="M26 26 H37 C41 26 42 21 47 18 H56 V46 H47 C42 43 41 38 37 38 H26" fill="none" stroke="#{blue}" stroke-width="4" stroke-linejoin="round"/>
        <circle cx="51" cy="24" r="2.7" fill="#{grey}"/>
        <circle cx="51" cy="40" r="2.7" fill="#{grey}"/>
      SVG
    when :appliances
      <<~SVG
        <rect x="14" y="7" width="36" height="50" rx="3" fill="none" stroke="#{blue}" stroke-width="3"/>
        <line x1="15" y1="21" x2="49" y2="21" stroke="#{red}" stroke-width="3"/>
        <circle cx="21" cy="14" r="2.5" fill="#{grey}"/>
        <circle cx="29" cy="14" r="2.5" fill="#{grey}"/>
        <circle cx="43" cy="14" r="2.5" fill="#{red}"/>
        <rect x="19" y="27" width="26" height="22" rx="2" fill="none" stroke="#{grey}" stroke-width="3"/>
        <line x1="21" y1="25" x2="43" y2="25" stroke="#{blue}" stroke-width="4" stroke-linecap="round"/>
        <path d="M23 43 C27 38 37 38 41 43" fill="none" stroke="#{red}" stroke-width="2.5" stroke-linecap="round"/>
      SVG
    when :operations
      <<~SVG
        <path d="M21 10 H43 L40 18 H24 Z" fill="none" stroke="#{blue}" stroke-width="3" stroke-linejoin="round"/>
        <path d="M27 18 L39 18 L26 50 L35 45 L31 55" fill="none" stroke="#{blue}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
        <line x1="24" y1="18" x2="40" y2="18" stroke="#{red}" stroke-width="3"/>
        <circle cx="31" cy="55" r="2.5" fill="#{grey}"/>
      SVG
    when :dimensions
      <<~SVG
        <path d="M12 17 H52 M12 47 H52 M18 11 V53 M46 11 V53" fill="none" stroke="#{blue}" stroke-width="2.5"/>
        <path d="M22 32 H42 M22 32 L28 27 M22 32 L28 37 M42 32 L36 27 M42 32 L36 37" fill="none" stroke="#{red}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
        <circle cx="18" cy="17" r="2.5" fill="#{grey}"/><circle cx="46" cy="47" r="2.5" fill="#{grey}"/>
      SVG
    else
      '<circle cx="32" cy="32" r="14" fill="none" stroke="#1479c9" stroke-width="3"/>'
    end
  end

  def self.create_svg(path, icon_id, on)
    symbol_opacity = on ? "1.0" : "0.78"
    symbol = icon_markup(icon_id)
    status = if on
               '<circle cx="55" cy="9" r="4" fill="#43bde3" stroke="#075d99" stroke-width="1.5"/>'
             else
               '<circle cx="55" cy="9" r="4" fill="none" stroke="#174562" stroke-width="1.5"/>'
             end

    svg = <<~SVG
      <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">
        <g opacity="#{symbol_opacity}">
          #{symbol}
        </g>
        #{status}
      </svg>
    SVG

    File.write(path, svg)
  end

  def self.existing_tags(button)
    model = Sketchup.active_model
    button[:tags].map { |tag_name| model.layers[tag_name] }.compact
  end

  def self.button_on?(button)
    tags = existing_tags(button)
    !tags.empty? && tags.all?(&:visible?)
  end

  def self.update_icon(button)
    cmd = @commands[button[:id]]
    return unless cmd

    state = button_on?(button)
    filename = File.join(icon_folder, "#{button[:id]}_#{state ? 'on' : 'off'}.svg")

    create_svg(filename, button[:id], state)

    cmd.small_icon = filename
    cmd.large_icon = filename
    cmd.tooltip = "#{button[:label]}: #{state ? 'ON' : 'OFF'}"
    cmd.status_bar_text = "Toggle #{button[:tags].join(', ')} (currently #{state ? 'ON' : 'OFF'})"
  end

  def self.toggle(button)
    model = Sketchup.active_model
    button[:tags].each do |tag_name|
      model.layers.add(tag_name) unless model.layers[tag_name]
    end
    tags = existing_tags(button)

    new_state = !tags.all?(&:visible?)
    model.start_operation("Toggle #{button[:label]}", true)
    tags.each { |tag| tag.visible = new_state }
    model.commit_operation

    update_icon(button)
    UI.refresh_toolbars
  end

  def self.start
    ensure_tags

    unless @app_observer
      @app_observer = AppObserver.new
      Sketchup.add_observer(@app_observer)
    end

    return if @toolbar && @toolbar.visible?

    @toolbar = UI::Toolbar.new("ELFIS Tags")
    @commands = {}

    BUTTONS.each do |button|
      cmd = UI::Command.new("Toggle #{button[:label]}") {
        toggle(button)
      }

      cmd.set_validation_proc do
        button_on?(button) ? MF_CHECKED : MF_UNCHECKED
      end

      @commands[button[:id]] = cmd
      update_icon(button)
      @toolbar.add_item(cmd)
      @toolbar.add_separator if button[:id] == :room || button[:id] == :back_wall || button[:id] == :operations
    end

    @toolbar.show
  end

  def self.refresh
    BUTTONS.each { |button| update_icon(button) }
    UI.refresh_toolbars
  end
end

ELFIS_TagToolbar.start
